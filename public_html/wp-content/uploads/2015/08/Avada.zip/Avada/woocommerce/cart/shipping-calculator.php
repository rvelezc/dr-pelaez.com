<?php
/**
 * Shipping Calculator
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// All of this code is housed in ~/framework/woo-config.php. Should be moved to this file.

// Omit closing PHP tag to avoid "Headers already sent" issues.
