<?php
get_header();

$sidebar_exists = false;
$sidebar_left = '';
$double_sidebars = false;
$content_class = '';

$sidebar_1 = Avada()->settings->get( 'portfolio_archive_sidebar' );
$sidebar_2 = Avada()->settings->get( 'portfolio_archive_sidebar_2' );
if( $sidebar_1 != 'None' && $sidebar_2 != 'None' ) {
	$double_sidebars = true;
}

if( $sidebar_1 != 'None' ) {
	$sidebar_exists = true;
} else {
	$sidebar_exists = false;
}

if( ! $sidebar_exists ) {
	$content_css = 'width:100%';
	$sidebar_css = 'display:none';
	$content_class = 'full-width';
	$sidebar_exists = false;
} elseif( Avada()->settings->get( 'portfolio_sidebar_position' ) == 'Left') {
	$content_css = 'float:right;';
	$sidebar_css = 'float:left;';
	$sidebar_left = 1;
} elseif( Avada()->settings->get( 'portfolio_sidebar_position' ) == 'Right') {
	$content_css = 'float:left;';
	$sidebar_css = 'float:right;';
	$sidebar_left = 2;
}

if($double_sidebars == true) {
	$content_css = 'float:left;';
	$sidebar_css = 'float:left;';
	$sidebar_2_css = 'float:left;';
} else {
	$sidebar_left = 1;
}
?>

<div id="content" class="<?php echo $content_class; ?>" style="<?php echo $content_css; ?>">

<?php get_template_part( 'templates/portfolio-archive', 'layout' ); ?>

</div>

<?php if( $sidebar_exists == true ): ?>

<div id="sidebar" class="sidebar" style="<?php echo $sidebar_css; ?>">
	<?php
	if($sidebar_left == 1) {
		generated_dynamic_sidebar($sidebar_1);
	}
	if($sidebar_left == 2) {
		generated_dynamic_sidebar_2($sidebar_2);
	}
	?>
</div>
<?php if( $double_sidebars == true ): ?>
<div id="sidebar-2" class="sidebar" style="<?php echo $sidebar_2_css; ?>">
	<?php
	if($sidebar_left == 1) {
		generated_dynamic_sidebar_2($sidebar_2);
	}
	if($sidebar_left == 2) {
		generated_dynamic_sidebar($sidebar_1);
	}
	?>
</div>
<?php endif; ?>
<?php endif; ?>
<?php get_footer();

// Omit closing PHP tag to avoid "Headers already sent" issues.
